-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Machine: 192.168.1.111:8091
-- Genereertijd: 17 jan 2013 om 16:22
-- Serverversie: 5.5.25
-- PHP-versie: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databank: `MatchTracker`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `leagues`
--

CREATE TABLE `leagues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `name_canonical` varchar(45) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `sport_types_id` int(11) NOT NULL,
  `description` text,
  `number_of_teams` int(11) DEFAULT NULL,
  `startdate` date DEFAULT NULL,
  `enddate` date DEFAULT NULL,
  `players_on_field` int(11) DEFAULT NULL,
  `fields` int(11) DEFAULT NULL,
  `place` varchar(255) DEFAULT NULL,
  `return_match` tinyint(1) DEFAULT NULL,
  `groups` int(11) DEFAULT NULL,
  `goesOn` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_leagues_users1` (`user_id`),
  KEY `fk_leagues_sport_types1` (`sport_types_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Gegevens worden uitgevoerd voor tabel `leagues`
--

INSERT INTO `leagues` (`id`, `name`, `name_canonical`, `user_id`, `sport_types_id`, `description`, `number_of_teams`, `startdate`, `enddate`, `players_on_field`, `fields`, `place`, `return_match`, `groups`, `goesOn`) VALUES
(1, 'Jupiler League', 'jupiler-league', 2, 1, 'Het populairste bier van België steunt ook de populairste sport in België: voetbal. Jupiler is al 15 jaar lang de trotse sponser van het Belgisch eersteklasvoetbal met de Jupiler Pro League én het nationale elftal. Want ook in het voetbal vind je de kernwaarden terug die in elk flesje Jupiler verscholen ligt: toewijding, perfectie en gezelligheid.', 16, '2012-12-28', '2013-05-08', 11, NULL, '', NULL, NULL, NULL),
(4, 'Jupiler Leaguee', 'jupiler-leaguee', 2, 1, 'Normally, both your asses would be dead as fucking fried chicken, but you happen to pull this shit while I\\''m in a transitional period so I don\\''t wanna kill you, I wanna help you. But I can\\''t give you this case, it don\\''t belong to me. Besides, I\\''ve already been through too much shit this morning over this case to hand it over to your dumb ass.', 4, '2012-12-28', '2012-12-29', 11, NULL, NULL, NULL, NULL, NULL),
(6, 'Jesse', 'jesseleague', 3, 1, 'test', 5, '2013-01-10', '2013-01-11', 11, 3, 'dunno', 0, NULL, NULL),
(7, 'Tester', 'tester', 1, 1, 'omschrijving....', 2, '2013-01-13', '2013-02-03', 11, NULL, NULL, 1, NULL, NULL),
(12, 'Tester 2', 'tester-2', 1, 1, '2 de teste competitie', 4, '2013-01-13', '2013-01-20', 11, NULL, NULL, 1, NULL, NULL),
(13, 'TestCompetitie', 'testcompetitie', 3, 2, 'Test', 4, '2013-01-11', '2013-01-14', 5, 2, 'Gebroeders Desmetstraat 1 Gent', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `leagues_has_standings`
--

CREATE TABLE `leagues_has_standings` (
  `leagues_id` int(11) NOT NULL,
  `standings_id` int(11) NOT NULL,
  PRIMARY KEY (`standings_id`,`leagues_id`),
  KEY `fk_leagues_has_standings_leagues1` (`leagues_id`),
  KEY `fk_leagues_has_standings_standings1` (`standings_id`),
  KEY `fk_standings` (`standings_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `leagues_has_standings`
--

INSERT INTO `leagues_has_standings` (`leagues_id`, `standings_id`) VALUES
(1, 1),
(7, 0);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `leagues_has_teams`
--

CREATE TABLE `leagues_has_teams` (
  `leagues_id` int(11) NOT NULL,
  `teams_id` int(11) NOT NULL,
  `invited` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`leagues_id`,`teams_id`),
  KEY `fk_leagues_has_teams_teams1` (`teams_id`),
  KEY `fk_leagues_has_teams_leagues1` (`leagues_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `leagues_has_teams`
--

INSERT INTO `leagues_has_teams` (`leagues_id`, `teams_id`, `invited`) VALUES
(1, 6, 0),
(1, 19, 0),
(1, 20, 0),
(1, 21, 0),
(1, 23, 0),
(1, 24, 0),
(1, 26, 0),
(1, 27, 0),
(1, 28, 0),
(1, 29, 0),
(1, 30, 0),
(1, 31, 0),
(1, 32, 0),
(1, 33, 0),
(1, 34, 0),
(1, 35, 0),
(4, 46, 0),
(7, 37, 0),
(7, 38, 0),
(7, 44, 0),
(7, 45, 0),
(12, 39, 0),
(12, 40, 0),
(12, 41, 0),
(12, 42, 0),
(12, 43, 0);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `matches`
--

CREATE TABLE `matches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `home_team` int(11) NOT NULL,
  `away_team` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `leagues_id` int(11) NOT NULL,
  `home_score` int(11) DEFAULT NULL,
  `away_score` int(11) DEFAULT NULL,
  `finished` int(1) DEFAULT '0',
  `active` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_matches_teams1` (`home_team`),
  KEY `fk_matches_teams2` (`away_team`),
  KEY `fk_matches_leagues1` (`leagues_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=95 ;

--
-- Gegevens worden uitgevoerd voor tabel `matches`
--

INSERT INTO `matches` (`id`, `home_team`, `away_team`, `date`, `start_time`, `leagues_id`, `home_score`, `away_score`, `finished`, `active`) VALUES
(1, 6, 19, '2013-11-01', '20:00:00', 1, 0, 1, 1, 0),
(2, 6, 19, '2013-11-01', '20:01:00', 4, 1, 3, 0, 0),
(89, 42, 43, '2013-01-13', NULL, 12, NULL, NULL, NULL, NULL),
(90, 39, 41, '2013-01-20', NULL, 12, NULL, NULL, NULL, NULL),
(91, 40, 43, '2013-01-27', NULL, 12, NULL, NULL, NULL, NULL),
(92, 40, 42, '2013-02-03', NULL, 12, NULL, NULL, NULL, NULL),
(93, 43, 40, '2013-02-10', NULL, 12, NULL, NULL, NULL, NULL),
(94, 41, 40, '2013-02-17', NULL, 12, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `matches_has_match_events`
--

CREATE TABLE `matches_has_match_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `matches_id` int(11) NOT NULL,
  `match_events_id` int(11) NOT NULL,
  `players_id` int(11) DEFAULT NULL,
  `teams_id` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_matches_has_match_events_match_events1` (`match_events_id`),
  KEY `fk_matches_has_match_events_matches1` (`matches_id`),
  KEY `fk_matches_has_match_events_players1` (`players_id`),
  KEY `fk_matches_has_match_events_teams1` (`teams_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Gegevens worden uitgevoerd voor tabel `matches_has_match_events`
--

INSERT INTO `matches_has_match_events` (`id`, `matches_id`, `match_events_id`, `players_id`, `teams_id`, `time`) VALUES
(1, 2, 1, 7, 6, 3),
(2, 2, 1, 7, 6, 10),
(3, 2, 1, 17, 19, 23),
(4, 2, 1, 17, 19, 80),
(5, 2, 1, 17, 19, 89),
(16, 1, 2, 7, 6, 0);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `match_events`
--

CREATE TABLE `match_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `text` text,
  `icon` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Gegevens worden uitgevoerd voor tabel `match_events`
--

INSERT INTO `match_events` (`id`, `name`, `text`, `icon`) VALUES
(1, 'goal', '%player% heeft gescoord voor %team% .', 'icon-star'),
(2, 'owngoal', '%player% scoorde een own goal.', 'icon-owngoal'),
(3, 'red card', '%player% kreeg een rode kaart.', 'icon-ticket.red'),
(4, 'yellow card', '%player% kreeg een gele kaart.', 'icon-ticket.yellow'),
(5, 'penalty', 'Penalty voor team %team% .', NULL),
(6, 'start', 'De wedstrijd tussen %team1% en %team2% is gestart', NULL),
(7, 'stop', 'Einde van de wedstrijd.', NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text,
  `receiver_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_messages_users1` (`receiver_id`),
  KEY `fk_messages_users2` (`sender_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `players`
--

CREATE TABLE `players` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(65) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `fieldPosition` varchar(65) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Gegevens worden uitgevoerd voor tabel `players`
--

INSERT INTO `players` (`id`, `name`, `age`, `number`, `fieldPosition`) VALUES
(1, 'Jesse Dobbelaere', 38, 12, NULL),
(5, 'Stephane Poppe', 22, 3, NULL),
(6, 'Bert Beeckman', 22, 4, NULL),
(7, 'Bert Beeckman', 22, 4, NULL),
(8, 'Silvio Proto', 20, 1, NULL),
(9, 'Olivier Deschacht', 20, 3, NULL),
(10, 'Lucas Biglia', 20, 5, NULL),
(11, 'Denis Odoi', 20, 8, NULL),
(12, 'Matias Suarez', 20, 9, NULL),
(13, 'Milan Jovanovic', 20, 11, NULL),
(14, 'Bram Nuytinck', 20, 14, NULL),
(15, 'Cheikhou Kouyaté', 20, 16, NULL),
(16, 'Sacha Kljestan', 20, 19, NULL),
(17, 'Tom De Sutter', 20, 21, NULL),
(18, 'Dieumerci Mbokani', 20, 25, NULL),
(19, 'Dennis Praet', 20, 26, NULL),
(20, 'Guillaume Gillet', 20, 31, NULL),
(21, 'Massimo Bruno', 20, 45, NULL),
(22, 'Christian Brüls', 20, 7, NULL),
(23, 'Bernd Thijs', 20, 8, NULL),
(24, 'Ilombe Mboyo', 20, 9, NULL),
(25, 'Shlomi Arbitman', 20, 10, NULL),
(26, 'Jordan Remacle', 20, 12, NULL),
(27, 'César Arzo', 20, 23, NULL),
(28, 'Hannes Van der Bruggen', 20, 13, NULL),
(29, 'Yaya Soumahoro', 20, 14, NULL),
(30, 'Rémi Maréval', 20, 16, NULL),
(31, 'Sergio Padt', 20, 19, NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sports`
--

CREATE TABLE `sports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Gegevens worden uitgevoerd voor tabel `sports`
--

INSERT INTO `sports` (`id`, `name`) VALUES
(1, 'Voetbal'),
(2, 'Tennis');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sport_types`
--

CREATE TABLE `sport_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `players_on_field` int(11) DEFAULT NULL,
  `sports_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_sport_types_sports1` (`sports_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Gegevens worden uitgevoerd voor tabel `sport_types`
--

INSERT INTO `sport_types` (`id`, `name`, `players_on_field`, `sports_id`) VALUES
(1, 'Veldvoetbal', 11, 1),
(2, 'Zaalvoetbal', 5, 1),
(3, 'Aangepast', NULL, 1),
(4, 'Enkel', 1, 2),
(5, 'Gemengd dubbel', 2, 2);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `standings`
--

CREATE TABLE `standings` (
  `idstandings` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `statistics_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`idstandings`),
  KEY `statistics_id` (`statistics_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `standings`
--

INSERT INTO `standings` (`idstandings`, `name`, `statistics_id`) VALUES
(0, 'Klassement', NULL),
(1, 'Algemeen klassement', NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `standings_has_statistics`
--

CREATE TABLE `standings_has_statistics` (
  `standings_id` int(11) NOT NULL,
  `statistics_id` int(11) NOT NULL,
  PRIMARY KEY (`standings_id`,`statistics_id`),
  KEY `standings_id` (`standings_id`),
  KEY `statistics_id` (`statistics_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `standings_has_statistics`
--

INSERT INTO `standings_has_statistics` (`standings_id`, `statistics_id`) VALUES
(0, 39),
(1, 5),
(1, 20),
(1, 21),
(1, 22),
(1, 23),
(1, 24),
(1, 25),
(1, 26),
(1, 27),
(1, 28),
(1, 29),
(1, 30),
(1, 31),
(1, 32),
(1, 33),
(1, 34);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `statistics`
--

CREATE TABLE `statistics` (
  `idstatistics` int(11) NOT NULL AUTO_INCREMENT,
  `teams_id` int(11) NOT NULL,
  `wins` int(11) DEFAULT NULL,
  `draws` int(11) DEFAULT NULL,
  `losses` int(11) DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  PRIMARY KEY (`idstatistics`),
  KEY `teams_id` (`teams_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Gegevens worden uitgevoerd voor tabel `statistics`
--

INSERT INTO `statistics` (`idstatistics`, `teams_id`, `wins`, `draws`, `losses`, `points`, `position`) VALUES
(5, 6, 0, 0, 1, 0, 2),
(20, 19, 1, 0, 0, 3, 1),
(21, 20, 0, 0, 0, 0, 3),
(22, 21, 0, 0, 0, 0, 4),
(23, 23, 0, 0, 0, 0, 15),
(24, 24, 0, 0, 0, 0, 6),
(25, 26, 0, 0, 0, 0, 7),
(26, 27, 0, 0, 0, 0, 8),
(27, 28, 0, 0, 0, 0, 9),
(28, 29, 0, 0, 0, 0, 10),
(29, 30, 0, 0, 0, 0, 11),
(30, 31, 0, 0, 0, 0, 12),
(31, 32, 0, 0, 0, 0, 13),
(32, 33, 0, 0, 0, 0, 14),
(33, 34, 0, 0, 0, 0, 16),
(34, 35, 0, 0, 0, 0, 5),
(35, 37, 0, 0, 0, 0, 1),
(36, 38, 0, 0, 0, 0, 1),
(37, 44, 0, 0, 0, 0, 1),
(38, 45, 0, 0, 0, 0, 1),
(39, 37, 0, 0, 0, 0, 1),
(40, 38, 0, 0, 0, 0, 1),
(41, 37, 0, 0, 0, 0, 1),
(42, 37, 0, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `teams`
--

CREATE TABLE `teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `name_canonical` varchar(100) DEFAULT NULL,
  `gameday` varchar(45) DEFAULT NULL,
  `gamehour` varchar(45) DEFAULT NULL,
  `gameplace` varchar(255) DEFAULT NULL,
  `email` varchar(70) DEFAULT NULL,
  `code` varchar(45) DEFAULT NULL,
  `place` varchar(255) DEFAULT NULL,
  `weekday` varchar(255) DEFAULT NULL,
  `hours` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_canonical_UNIQUE` (`name_canonical`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=48 ;

--
-- Gegevens worden uitgevoerd voor tabel `teams`
--

INSERT INTO `teams` (`id`, `name`, `name_canonical`, `gameday`, `gamehour`, `gameplace`, `email`, `code`, `place`, `weekday`, `hours`) VALUES
(6, 'AA Gent', 'aa-gent', NULL, NULL, NULL, 'test@test.be', 'e1a2c522d3808bc14679', 'Staatsbaan 4, Maldegem, België', 'a:1:{i:0;s:3:"sat";}', '20u'),
(19, 'Anderlecht', 'anderlecht', NULL, NULL, NULL, 'test@test.be', 'fe9c20a8d6e478c0da7b', NULL, 'a:1:{i:0;s:3:"sun";}', '20'),
(20, 'Zulte Waregem', 'zulte-waregem', NULL, NULL, NULL, 'test@test.be', 'a99d8b064dfcad5b3131', NULL, 'N;', NULL),
(21, 'Lokeren', 'lokeren', NULL, NULL, NULL, 'test@test.be', 'c718ea8aa566341c5f60', NULL, 'N;', NULL),
(23, 'Club Brugge', 'club-brugge', NULL, NULL, NULL, 'test@test.be', '915e7b324d9e1b85f4b0', NULL, 'N;', NULL),
(24, 'Standard', 'standard', NULL, NULL, NULL, 'test@test.be', '2dcd8c8db3464afabf3b', NULL, 'N;', NULL),
(26, 'Racing Genk', 'racing-genk', NULL, NULL, NULL, 'test@test.be', '60a1629746b3416fc558', NULL, 'N;', NULL),
(27, 'Bergen', 'bergen', NULL, NULL, NULL, 'test@test.be', 'fc511f24338a12af5b9d', NULL, 'N;', NULL),
(28, 'Kortrijk', 'kortrijk', NULL, NULL, NULL, 'test@test.be', '194138652426a18c88cd', NULL, 'N;', NULL),
(29, 'KV Mechelen', 'kv-mechelen', NULL, NULL, NULL, 'test@test.be', '3b55b587372507d168a7', NULL, 'N;', NULL),
(30, 'OH Leuven', 'oh-leuven', NULL, NULL, NULL, 'test@test.be', '4159e1ad914e4d008125', NULL, 'N;', NULL),
(31, 'Charleroi', 'charleroi', NULL, NULL, NULL, 'test@test.be', '38fd1d86e81d594c30ad', NULL, 'N;', NULL),
(32, 'Waasland-Beveren', 'waasland-beveren', NULL, NULL, NULL, 'test@test.be', '8d8f5ab0f9416cfb548c', NULL, 'N;', NULL),
(33, 'Beerschot AC', 'beerschot-ac', NULL, NULL, NULL, 'test@test.be', 'c3b21b9a7b1db32a68ad', NULL, 'N;', NULL),
(34, 'Lierse SK', 'lierse-sk', NULL, NULL, NULL, 'test@test.be', 'ab4f21f2bb08226d3f38', NULL, 'N;', NULL),
(35, 'Cercle Brugge', 'cercle-brugge', NULL, NULL, NULL, 'test@test.be', '5eaa618db75df0f6a13b', NULL, 'N;', NULL),
(37, 'Manchester United', 'manchester-united', NULL, NULL, NULL, NULL, '1343330c64f3e5ec8c15', NULL, 'N;', NULL),
(38, 'Arsenal', 'arsenal', NULL, NULL, NULL, NULL, '1ffacb65f6ee8a75b391', NULL, 'N;', NULL),
(39, 'Testploeg1', 'testploeg1', NULL, NULL, NULL, NULL, '69524d5c45b29fe03d4c', NULL, 'N;', NULL),
(40, 'Testploeg2', 'testploeg2', NULL, NULL, NULL, NULL, 'f897a44a2b449b615b7a', NULL, 'N;', NULL),
(41, 'TestPloeg3', 'testploeg3', NULL, NULL, NULL, NULL, 'e526b54a41319a4b7c99', NULL, 'N;', NULL),
(42, 'TestpLoeg4', 'testploeg4', NULL, NULL, NULL, NULL, '8d4ff34f6730a71457f0', NULL, 'N;', NULL),
(43, NULL, NULL, NULL, NULL, NULL, NULL, '25ab370af0d68e4319d1', NULL, 'N;', NULL),
(44, 'Manchester City', 'manchester-city', NULL, NULL, NULL, NULL, '5b10ba1f2affc5fe119d', NULL, 'N;', NULL),
(45, 'WBA', 'wba', NULL, NULL, NULL, NULL, '9f2b159a7f5c69d00cd6', NULL, 'N;', NULL),
(46, 'BertsTeam', 'bertsteam', NULL, NULL, NULL, 'mail@beeckmanbert.be', '540c9a09b62c9e7d8bf7', NULL, 'N;', NULL),
(47, NULL, NULL, NULL, NULL, NULL, NULL, '5c75075c96a1d17590c0', NULL, 'N;', NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `teams_has_players`
--

CREATE TABLE `teams_has_players` (
  `teams_id` int(11) NOT NULL,
  `players_id` int(11) NOT NULL,
  PRIMARY KEY (`teams_id`,`players_id`),
  KEY `fk_teams_has_players_teams1_idx` (`teams_id`),
  KEY `fk_teams_has_players_players1_idx` (`players_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden uitgevoerd voor tabel `teams_has_players`
--

INSERT INTO `teams_has_players` (`teams_id`, `players_id`) VALUES
(6, 1),
(6, 5),
(6, 7),
(6, 22),
(6, 23),
(6, 24),
(6, 25),
(6, 26),
(6, 27),
(6, 28),
(6, 29),
(6, 30),
(6, 31),
(19, 8),
(19, 9),
(19, 10),
(19, 11),
(19, 12),
(19, 13),
(19, 14),
(19, 15),
(19, 16),
(19, 17),
(19, 18),
(19, 19),
(19, 20),
(19, 21);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `username_canonical` varchar(255) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `facebookId` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `email_canonical` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `locked` tinyint(1) NOT NULL,
  `expired` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  `confirmation_token` varchar(255) DEFAULT NULL,
  `password_requested_at` datetime DEFAULT NULL,
  `roles` longtext NOT NULL COMMENT '(DC2Type:array)',
  `credentials_expired` tinyint(1) NOT NULL,
  `credentials_expire_at` datetime DEFAULT NULL,
  `twitterID` varchar(255) DEFAULT NULL,
  `twitter_username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_957A647992FC23A8` (`username_canonical`),
  UNIQUE KEY `UNIQ_957A6479A0D96FBF` (`email_canonical`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Gegevens worden uitgevoerd voor tabel `users`
--

INSERT INTO `users` (`id`, `username`, `username_canonical`, `firstname`, `lastname`, `facebookId`, `email`, `email_canonical`, `enabled`, `salt`, `password`, `last_login`, `locked`, `expired`, `expires_at`, `confirmation_token`, `password_requested_at`, `roles`, `credentials_expired`, `credentials_expire_at`, `twitterID`, `twitter_username`) VALUES
(1, '658348746', '658348746', 'Stéphane', 'Poppe', '658348746', 'stephanepuppe@hotmail.com', 'stephanepuppe@hotmail.com', 1, 'k159xb90nsgs88skww8skw4og04sook', '', '2013-01-11 05:39:37', 0, 0, NULL, NULL, NULL, 'a:0:{}', 0, NULL, NULL, NULL),
(2, 'bert', 'bert', 'Bert', 'Beeckman', NULL, 'bert@bert.be', 'bert@bert.be', 1, 'sdot28wvryocg4c8sks0ogcgcc4kcw4', 'Q7+dgxnvRBFPSNq0J44BqNqVaEIWaq1sa8ezWDFXdHyTLl2BF/qv6zAmyozoNjLSLtB3GcV0E5AFNeqfuKz7+w==', '2013-01-11 20:20:01', 0, 0, NULL, NULL, NULL, 'a:0:{}', 0, NULL, NULL, NULL),
(3, '1382515393', '1382515393', 'Jesse', 'Dobbelaere', '1382515393', 'jesse@dobbelaere-ae.be', 'jesse@dobbelaere-ae.be', 1, 'gf5f4xzrhhs8o8gwsogo0s4s4cc44sg', '', '2013-01-11 20:25:47', 0, 0, NULL, NULL, NULL, 'a:0:{}', 0, NULL, NULL, NULL),
(4, 'jelle', 'jelle', NULL, NULL, NULL, 'jelle@jelle.be', 'jelle@jelle.be', 1, 'adwaol7h1lsk4gw0ks8ocwo44wck8ow', 'a5lvYP9XZql22Pmqpd0gBrjIRA8H7G+i232oQckZN4m3e9Tsf8pmHK5++h/liiY4K0Blx+jCYoZxnUmFyRS5+w==', '2012-12-30 13:58:07', 0, 0, NULL, NULL, NULL, 'a:0:{}', 0, NULL, NULL, NULL);

--
-- Beperkingen voor gedumpte tabellen
--

--
-- Beperkingen voor tabel `leagues`
--
ALTER TABLE `leagues`
  ADD CONSTRAINT `fk_leagues_sport_types1` FOREIGN KEY (`sport_types_id`) REFERENCES `sport_types` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_leagues_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `leagues_has_standings`
--
ALTER TABLE `leagues_has_standings`
  ADD CONSTRAINT `fk_leagues_has_standings_leagues1` FOREIGN KEY (`leagues_id`) REFERENCES `leagues` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_standings` FOREIGN KEY (`standings_id`) REFERENCES `standings` (`idstandings`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `leagues_has_teams`
--
ALTER TABLE `leagues_has_teams`
  ADD CONSTRAINT `fk_leagues_has_teams_leagues1` FOREIGN KEY (`leagues_id`) REFERENCES `leagues` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_leagues_has_teams_teams1` FOREIGN KEY (`teams_id`) REFERENCES `teams` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `matches`
--
ALTER TABLE `matches`
  ADD CONSTRAINT `fk_matches_leagues1` FOREIGN KEY (`leagues_id`) REFERENCES `leagues` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_matches_teams1` FOREIGN KEY (`home_team`) REFERENCES `teams` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_matches_teams2` FOREIGN KEY (`away_team`) REFERENCES `teams` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `matches_has_match_events`
--
ALTER TABLE `matches_has_match_events`
  ADD CONSTRAINT `fk_matches_has_match_events_matches1` FOREIGN KEY (`matches_id`) REFERENCES `matches` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_matches_has_match_events_match_events1` FOREIGN KEY (`match_events_id`) REFERENCES `match_events` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_matches_has_match_events_players1` FOREIGN KEY (`players_id`) REFERENCES `players` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_matches_has_match_events_teams1` FOREIGN KEY (`teams_id`) REFERENCES `teams` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `fk_messages_users1` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_messages_users2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `sport_types`
--
ALTER TABLE `sport_types`
  ADD CONSTRAINT `fk_sport_types_sports1` FOREIGN KEY (`sports_id`) REFERENCES `sports` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `standings_has_statistics`
--
ALTER TABLE `standings_has_statistics`
  ADD CONSTRAINT `standings_id` FOREIGN KEY (`standings_id`) REFERENCES `standings` (`idstandings`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `statistics_id` FOREIGN KEY (`statistics_id`) REFERENCES `statistics` (`idstatistics`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `statistics`
--
ALTER TABLE `statistics`
  ADD CONSTRAINT `teams_id` FOREIGN KEY (`teams_id`) REFERENCES `teams` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Beperkingen voor tabel `teams_has_players`
--
ALTER TABLE `teams_has_players`
  ADD CONSTRAINT `fk_teams_has_players_players1` FOREIGN KEY (`players_id`) REFERENCES `players` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_teams_has_players_teams1` FOREIGN KEY (`teams_id`) REFERENCES `teams` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
